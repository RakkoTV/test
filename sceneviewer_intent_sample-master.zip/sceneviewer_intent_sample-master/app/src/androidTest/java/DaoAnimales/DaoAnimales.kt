package DaoAnimales

import blog.creativetech.sceneviewerdemo.R

public class DaoAnimales constructor(
                        nombre:String,
                       descripcion:String,
                       url:String,
                       objeto3D:String,
                       region: Int) {

fun obtenerAnimalDao(region:Int): Animal{
    //Crear Funcion en la clase de Acceso a Base de datos DbHelper.kt

    // return obtenerAnimalDbHelper(region) //DbHelper
}

}


    /*

    //DbHelper
    fun obtenerAnimalDbHelper(region: Int): Animal {
    val animal = Animal()
    animal.region=region
    val db = writableDatabase

    val selectQuery = getString(R.string.queryObtenerAnimalDadaRegion)+region
    val cursor = db.rawQuery(selectQuery, null)
    if (cursor != null) {
        cursor.moveToFirst()
        while (cursor.moveToNext()) {
            animal.nombre = cursor.getString(cursor.getColumnIndex(NAME))
            animal.descripcion = cursor.getString(cursor.getColumnIndex(DESC))
            nimal.url = cursor.getString(cursor.getColumnIndex(URL))
            animal.objeto3D = cursor.getString(cursor.getColumnIndex(OBJ))
        }
    }
    cursor.close()
    return animal
}
     */


