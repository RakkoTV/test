package Animal

public class Animal constructor (
    nombre:String,
    descripcion:String,
    url:String,
    objeto3D:String,
    region: Int
)
{

    fun obtenerAnimal(): Animal {

            return this
    }


}