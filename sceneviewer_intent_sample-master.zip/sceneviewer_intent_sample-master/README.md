Scene Viewer
<b> Interactive AR with Scene Viewer and Android Intent</b> <br/>
Blog post -> https://creativetech.blog/home/scene-viewer-with-android-intent
<br/>
<br/>


Settings             |  Scene Viewer Preview
:-------------------------:|:-------------------------:
![](https://github.com/Kristina-Simakova/sceneviewer_intent_sample/blob/master/SceneViewerSettings.png)  |  ![](https://github.com/Kristina-Simakova/sceneviewer_intent_sample/blob/master/ScenneViewerIntentDemo.png)

